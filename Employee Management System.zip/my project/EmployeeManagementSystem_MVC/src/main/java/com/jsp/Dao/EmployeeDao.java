package com.jsp.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Dto.Employee;

@Repository
public class EmployeeDao {
	
	@Autowired
	EntityManager manager;
	
	@Autowired
	EntityTransaction transaction;
	
	//To insert employee into db..
	public String insertEmployee(Employee employee)
	{
		transaction.begin();
		manager.persist(employee);
		transaction.commit();
		
		return "successfully stored in the data base";
	}
	
	//To find an employee object based on id...
	public Employee findEmployeeById(int id)
	{
		Employee emp= manager.find(Employee.class,id);
		if(emp!=null)
		{
			return emp;
		}
		else
		{
			return null;
		}
	}
	
	//To delete the employee obj based on db...
	public int DeleteEmployeeById(int id)
	{
		Employee emp= manager.find(Employee.class,id);
		if(emp!=null)
		{
			transaction.begin();
			manager.remove(emp);
			transaction.commit();
			return 0;
		}
		return 1;
	}
	
	//To update the employee obj in db...
	public int UpdateEmployeeById(int id,String newName, long newPhone)
	{
		Employee emp= manager.find(Employee.class,id);
		if(emp!=null)
		{
			emp.setName(newName);
			emp.setPhone(newPhone);
			transaction.begin();
			manager.merge(emp);
			transaction.commit();
			return 0;
		}
		return 1;
	}
	
	//To fetch the employee obj in a db...
	public List<Employee> getAllEmployees()
	{
		Query q= manager.createQuery("select e from employee e");
		List<Employee> employeeList=q.getResultList();
		return employeeList;
		
	}
	

}
